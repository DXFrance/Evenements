﻿Param(  
    #Paramètres du Azure Ressource Group
    $resourceGroupeName = "...RGStorage",
    $resourceGroupeDeploymentName = "...RGStorageDep",
    $resourceLocation = "West Europe",
    $publishSettingsFile = (Resolve-Path "....publishsettings"),
    $subscriptionName = "...",
    $templateFile = "Storage.json",
    $tagName = "..._RG_Status",
    $tagValue = "Temporary"
    )

$PSVersionTable

#region init
Set-PSDebug -Strict

cls
$d = get-date
Write-Host "Starting Deployment $d"

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "scriptFolder" $scriptFolder

set-location $scriptFolder
#endregion init

#region Souscription
#Remove-AzureAccount 
#Add-AzureAccount
Get-AzureAccount
Select-AzureSubscription -SubscriptionName $subscriptionName
#endregion Souscription

Switch-AzureMode -Name AzureResourceManager

# Création d'un resource groupe
New-AzureResourceGroup `
	-Name $resourceGroupeName `
	-Location $resourceLocation `
    -Tag @{Name=$tagName;Value=$tagValue} `
    -Verbose

# Déploiement du resource group
New-AzureResourceGroupDeployment `
    -Name $resourceGroupeDeploymentName `
	-ResourceGroupName $resourceGroupeName `
	-TemplateFile $templateFile `
    -Verbose

Get-AzureResourceGroup -Name $resourceGroupeName
(Get-AzureResourceGroup -Name $resourceGroupeName).Tags
Get-AzureResourceGroupLog -ResourceGroup $resourceGroupeName

#Remove-AzureResourceGroup -Name $resourceGroupeName

$d = get-date
Write-Host "Stopping Deployment $d"