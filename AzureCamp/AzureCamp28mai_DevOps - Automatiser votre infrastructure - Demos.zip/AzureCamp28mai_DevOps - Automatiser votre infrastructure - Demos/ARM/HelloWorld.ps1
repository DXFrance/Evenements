﻿Param(  
    #Paramètres du Azure Ressource Group
    $resourceGroupeName = "...RGHello",
    $resourceGroupeDeploymentName = "...RGHelloDep",
    $resourceLocation = "West Europe",
    $publishSettingsFile = (Resolve-Path "....publishsettings"),
    $subscriptionName = "...",
    $templateFile = "HelloWorld.json",
    $tagName = "..._RG_Status",
    $tagValue = "Temporary"
    )

$PSVersionTable

#region init
Set-PSDebug -Strict

cls
$d = get-date
Write-Host "Starting Deployment $d"

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "scriptFolder" $scriptFolder

set-location $scriptFolder
#endregion init

#region Souscription
#Remove-AzureAccount 
#Add-AzureAccount
Get-AzureAccount
Select-AzureSubscription -SubscriptionName $subscriptionName
#endregion Souscription

Switch-AzureMode -Name AzureResourceManager
#Get-Command -Module AzureResourceManager | Get-Help | Format-Table Name, Synopsis
get-help New-AzureResourceGroup -detailed
get-help New-AzureResourceGroupDeployment -detailed

# Liste des templates json dans la galerie
#Get-AzureResourceGroupGalleryTemplate | Format-Table Identity


# Création d'un resource groupe
New-AzureResourceGroup `
	-Name $resourceGroupeName `
	-Location $resourceLocation `
    -Tag @{Name=$tagName;Value=$tagValue} `
    -Verbose

# Déploiement du resource group
New-AzureResourceGroupDeployment `
    -Name $resourceGroupeDeploymentName `
	-ResourceGroupName $resourceGroupeName `
	-TemplateFile $templateFile `
    -Verbose

Get-AzureResource | Group-object ResourceType | Sort-Object count -descending | select Name 

#Remove-AzureResourceGroup -Name $resourceGroupeName

$d = get-date
Write-Host "Stopping Deployment $d"