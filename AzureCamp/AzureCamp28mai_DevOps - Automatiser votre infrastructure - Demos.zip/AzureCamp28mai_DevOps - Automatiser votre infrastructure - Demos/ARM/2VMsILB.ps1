﻿#https://github.com/Azure/azure-quickstart-templates/tree/master/201-2-vms-internal-load-balancer

Param(  
    #Paramètres du Azure Ressource Group
    $resourceGroupeName = "...RG",
    $resourceGroupeDeploymentName = "...RGILBDeployed",
    $resourceLocation = "West Europe",
    $storageAccountNameFromTemplate = "...templates",
    $publishSettingsFile = (Resolve-Path "....publishsettings"),
    $subscriptionName = "...InTheCloud",
    $templateFile = "azuredeploy.json",
    $templateParameterFile = "azuredeploy-parameters.json",
    $tagName = "..._RG_Status",
    $tagValue = "Temporary"
    )

#region init
Set-PSDebug -Strict

cls
$d = get-date
Write-Host "Starting Deployment $d"

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "scriptFolder" $scriptFolder

set-location $scriptFolder
#endregion init

#region Souscription
#Remove-AzureAccount 
#Add-AzureAccount
Get-AzureAccount
Select-AzureSubscription -SubscriptionName $subscriptionName
#endregion Souscription

Switch-AzureMode -Name AzureResourceManager

# Création d'un resource groupe
New-AzureResourceGroup `
	-Name $resourceGroupeName `
	-Location $resourceLocation `
    -Tag @{Name=$tagName;Value=$tagValue} `
    -Verbose

# Déploiement du resource group
New-AzureResourceGroupDeployment `
    -Name $resourceGroupeDeploymentName `
	-ResourceGroupName $resourceGroupeName `
	-TemplateFile $templateFile `
	-TemplateParameterFile $templateParameterFile `
    -StorageAccountNameFromTemplate $storageAccountNameFromTemplate `
    -Verbose

$d = get-date
Write-Host "Stopping Deployment $d"