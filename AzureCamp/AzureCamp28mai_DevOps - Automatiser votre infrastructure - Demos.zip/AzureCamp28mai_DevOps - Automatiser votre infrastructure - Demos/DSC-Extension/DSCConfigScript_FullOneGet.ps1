﻿configuration AzureCampConfig
{
    Import-DSCResource -Module xOneGet 

        XOneGet SysInternals
        {
            PackageName           = "sysinternals"
            Ensure                = "Present"
        }
        XOneGet Zoomit
        {
            PackageName           = "zoomit"
            Ensure                = "Present"
        }
        XOneGet VIM
        {
            PackageName           = "vim"
            Ensure                = "Present"
        }
        XOneGet GoogleChrome
        {
            PackageName           = "GoogleChrome"
            Ensure                = "Present"
        }

        
}