﻿The latest version of OneGet can be found at http://oneget.codeplex.com


Install:

    ***********
    Note: Currenty, you should have the original Chocolatey installed. It turns
          out that the original is needed because some installers steal 
          functions out of the chocolatey scripts instead of using functions 
          from the Helpers module. This will be fixed very soon.
    
        Install Chocolatey (from http://chocolatey.org/): 
        
        @powershell -NoProfile -ExecutionPolicy unrestricted -Command "iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))" && SET PATH=%PATH%;%systemdrive%\chocolatey\bin
        
    **********
    
    Installing OneGet:
    
        Unzip into a folder
    
        Run in powershell:
            import-module .\OneGet.psd1
        

Known Bugs:

    The Chocolatey Repository ( https://chocolatey.org/api/v2/ ) has a bug.
    If you leave off the trailing slash, it will redirect to http://.... 
    if you have a package https:// source without the trailing slash and it
    is marked trusted, it will behave incorrectly because the source is getting
    rewritten.

    Currently, original chocolatey is needed because some installers steal 
    fns out of the chocolatey scripts instead of using fns from Helpers.
    
    Failure during install leaves package unpacked (and looks installed) 
    in choco/lib
    
    Downloads should find previously completed downloads and use them 
    instead of re-downloading
    
    need more progress in longer-running operations (like unzip&tracking).
    
    could sure use more verbose messages in helpers when stuff fails.
    
    7za.exe isn't in  "$env:ChocolateyInstall" 'chocolateyinstall\tools\7za.exe' 
    on some systems  (shouldn't be needed once we've moved off of using 7za)
    
    unzip & tracking to c:\ is TERRIBLE! EEEEW. 
    (seen during install of eclipse-java-kepler)

Changes:
    -	This build bootstraps NuGet.exe off the web. 
    -   PackageSources now have a 'trusted' flag.
    -   InstallPackage checks the source trusted flag and warns on untrusted \
    -   removed the terrible script warning 
    -   WhatIf works a bit better. 

    
Other Thoughts:
    -	Not much any new functionality in this build, just some changes on how things are done.
    -	Messages are poor quality right now (revisions soon)
    -	Error messages are just written to error stream, will be turned into proper powershell error objects soon
    -	More (detailed) progress messages will be coming soon
    -	Security Prompts  are preliminary (some changes coming soon)
    -	Other things I’m not remembering right now….
