﻿configuration Sample_xOneGet_InstallPackage
{
    param 
    (
        [string[]]$NodeName = 'localhost'
    )

    Import-DscResource -Module XOneGet

    Node $NodeName
    {
        XOneGet InstallPackage
        {
            PackageName           = "7zip"
            Ensure                = "Present"
        }
    }
 }

Sample_xOneGet_InstallPackage
Start-DscConfiguration -Path Sample_xOneGet_InstallPackage -Wait -Verbose -Force