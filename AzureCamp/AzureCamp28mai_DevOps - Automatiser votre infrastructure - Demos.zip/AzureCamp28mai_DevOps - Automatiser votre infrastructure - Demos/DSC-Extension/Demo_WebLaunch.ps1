﻿#region Parameters
Param(  
    $dscContainerName = "dscenv",
    $dscConfigurationName = "AzureCampConfig",

    # Name of the storage account to publish to
    $storageAccountName = "...",

    # Azure storage account key
    $storageAccountKey = (Get-AzureStorageKey -StorageAccountName $storageAccountName).Primary,

    $userName = "...",
    $password =  "Pass@word1",

    # Azure publish settings file to import
    $publishSettingsFile = (Resolve-Path "....publishsettings"),

    # Name of the subscription to use for azure cmdlets
    $subscriptionName = "...",

    # DSC configuration script filename
    $configScript = "DSCConfigScript_Web.ps1",

    $vmName = "dscweb",
    $serviceName = "dsc-web-mgt"
    )
#endregion Parameters

Set-PSDebug -Strict

cls
$d = get-date
Write-Host "Starting Deployment $d"


#region Setup

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "scriptFolder" $scriptFolder

set-location $scriptFolder
$resolvePath = "$scriptFolder\$configScript"


#Import-Module Azure
#
# Load settings to use for Azure access
#
Import-AzurePublishSettingsFile -PublishSettingsFile $publishSettingsFile
Select-AzureSubscription -SubscriptionName $subscriptionName
Set-AzureSubscription -CurrentStorageAccountName $storageAccountName -SubscriptionName $subscriptionName

#
# Create the container for the environment
#
$storageContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
New-AzureStorageContainer -Name $dscContainerName -Context $storageContext -ErrorAction Ignore

#endregion SETUP

function GetLatestImage
{
   param($imageFamily)
   $images = Get-AzureVMImage | where { $_.ImageFamily -eq $imageFamily } | Sort-Object -Descending -Property PublishedDate
   return $images[0].ImageName
}

#$vmImage = "a699494373c04fc0bc8f2bb1389d6106__Windows-Server-2012-R2-201403.01-en.us-127GB.vhd"
$vmImage = (GetLatestImage "Windows Server 2012 R2 Datacenter")

#
# Publish the configuration to Azure
#
Publish-AzureVMDSCConfiguration -ConfigurationPath $resolvePath -StorageContext $storageContext -ContainerName $dscContainerName -Force
#Publish-AzureVMDSCConfiguration -ConfigurationPath $resolvePath -ConfigurationArchivePath "$resolvePath.zip" -Force

#
# Create the VM configuration to use
#
$vmConfig = New-AzureVMConfig -Name $vmName -InstanceSize Small -ImageName $vmImage
$vmConfig = Add-AzureProvisioningConfig -VM $vmConfig -Windows `
                    -Password $password `
                    -AdminUsername $userName

#
# Setup the DSC extension
#
$vmConfig = Set-AzureVMDSCExtension -VM $vmConfig -ConfigurationArchive "$configScript.zip" `
             -ConfigurationName $dscConfigurationName -ContainerName $dscContainerName 

# Add 80 endpoint
$vmConfig = Add-AzureEndpoint -VM $vmConfig -Name "HTTP" -Protocol tcp -LocalPort 80 -PublicPort 80

# Finally create a new VM with the above configuration
New-AzureVM -Location "West Europe" -ServiceName $serviceName -VM $vmConfig -WaitForBoot

# You can use the Azure management portal to examine the VM creation process
# or retrieve the VM object as follows:
$myVM = Get-AzureVM -ServiceName $serviceName -Name $vmName

PAUSE

$status = $myVM | Get-AzureVMDscExtensionStatus

$status

$status.DscConfigurationLog


$d = get-date
Write-Host "Stopping Deployment $d"
