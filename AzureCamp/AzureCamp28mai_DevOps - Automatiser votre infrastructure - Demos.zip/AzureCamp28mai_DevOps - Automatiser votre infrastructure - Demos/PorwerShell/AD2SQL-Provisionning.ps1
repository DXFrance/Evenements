﻿#region Parameters
Param(  
        #credentials
        $publishSettingsFile = (Resolve-Path "...publishsettings"),

        #DC location, affinity group, storage, and subscription
        #$affinityGroup = "NotRequiredAnyMoreInThisDemo",
        #$affinityGroupLabel = "NotRequiredAnyMoreInThisDemo",
        $location = "West Europe",
        $azureSubscription = "...",
        $storageAccount = "...", 
        #$storageAccountLabel = "NotRequiredAnyMoreInThisDemo",
        $adminUserName = "...",

        #Network
        $virtualNetworkName = "AD2SQL-VNet",
        $networkConfigFile = "AD2SQL-NetworkConfig.xml",
        $sqlBackendSubnet = "SQLBackendSubnet",
        $dcSubnet = "DCSubnet",

        #Active Directory
        $dcServiceName = "ad2sql-ad",
        $dcVMName = "AD2SQL-DC",
        $dcAdminPort = 52101,
        $adAvailabilitySet = "DCAvailabilitySet",
        $dcInstanceSize = "Small",
        $hostCaching = "ReadWrite",
        $domainName = "....demo.com",
        $domainNetbiosName = "...",
        $adDeploymentLabel = "AD2SQL-DC Active Directory Deployment",
        $adDeploymentName = "AD2SQL-DCDeploy",

        #SQL VMs
        $sqlServiceName = "ad2sql-sql",
        $sqlVMPrefix = "AD2SQL-SQL",
        $sqlAdminPort = 53100,
        $sqldiskLabel = "AD2SQLDisk-SQL-",
        $sqlAvailabilitySet = "SQLAvailabilitySet",
        $sqlInstanceSize = "Medium",
        $sqlDeploymentLabel = "AD2SQL-SQL Active Directory Deployment",
        $sqlDeploymentName = "AD2SQL-SQLDeploy",
        $nbSQLVMs = 2
     )
#endregion Parameters

function GetLatestImage
{
   param($imageFamily)
   $images = Get-AzureVMImage | where { $_.ImageFamily -eq $imageFamily } | Sort-Object -Descending -Property PublishedDate
   return $images[0].ImageName
}

#region function definition for PowerShell remoting
function InstallWinRMCert($dcServiceName, $vmname)
{
    $winRMCert = (Get-AzureVM -ServiceName $dcServiceName -Name $vmname | select -ExpandProperty vm).DefaultWinRMCertificateThumbprint
 
    $AzureX509cert = Get-AzureCertificate -ServiceName $dcServiceName -Thumbprint $winRMCert -ThumbprintAlgorithm sha1
 
    $certTempFile = [IO.Path]::GetTempFileName()
    Write-Host $certTempFile
    $AzureX509cert.Data | Out-File $certTempFile
 
    # Target The Cert That Needs To Be Imported
    $CertToImport = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $certTempFile
 
    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store "Root", "LocalMachine"
    $store.Certificates.Count
    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
    $store.Add($CertToImport)
    $store.Close()
 
    Remove-Item $certTempFile
}
#endregion

#reinit powershell cache
#C:\Users\stephgou\AppData\Roaming\Windows Azure Powershell
#Remove-AzureAccount "stephgou@live.fr"
cls
write-host "------------------------------------------------------------"
write-host "        Provisioning d'une infra AD + 2 serveurs SQL        "
write-host "------------------------------------------------------------"

#region set default Windows Azure subscription


#$adminPassword="******obfuscated*****"
#region secret
$adminPassword="Pass@word1"
#endregion


$d = get-date
Write-Host "Starting Deployment $d"


Switch-AzureMode -Name AzureServiceManagement


$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "scriptFolder" $scriptFolder
set-location $scriptFolder


#Add-AzureAccount #-Environment $azureSubscription -SubscriptionDataFile $azurePublishsettingsFile
# ----- Import azurePublishsettingsFile
# This file contains an encoded management certificate. It serves as your credentials to administer your subscriptions and related services. 
# Store this file in a secure location or delete it after you use it.
#
Import-AzurePublishSettingsFile -PublishSettingsFile $publishSettingsFile
Select-AzureSubscription -SubscriptionName $azureSubscription
Set-AzureSubscription -CurrentStorageAccountName $storageAccountName -SubscriptionName $azureSubscription

#
#region ----- Affinity Group Creation
# Affinity groups are the way to group the services in your Windows Azure subscription that need to work together in order to achieve optimal performance. 
# When you create an affinity group, it lets Windows Azure When you create an affinity group, it lets Windows Azure know to keep all of the services that 
# belong to your affinity group running at the same data center cluster
#write-host "Affinity Group Creation :" $affinityGroup
#New-AzureAffinityGroup -Name $affinityGroup -Label $affinityGroupLabel -Location $Location
#endregion

#region ----- Storage Account Creation
# A storage account provides access to the Windows Azure Blob, Table, and Queue services within a geographic region. 
# A storage account can contain 500 TB of data. 
#write-host "Storage Account Creation :" $storageAccount
#New-AzureStorageAccount -StorageAccountName $storageAccount -Label $storageAccountLabel -AffinityGroup $affinityGroup
#endregion

# ------ Set current storage account and Azure subscription
write-host "Set current Azure subscription :" $azureSubscription
write-host "Set current storage account :" $storageAccount
Set-AzureSubscription -SubscriptionName $azureSubscription -CurrentStorageAccount $storageAccount

# ------ Virtual Network Creation
# Virtual network address space and settings that we want to use for our virtual machines.
write-host "Virtual Network Creation from XML file import :" $networkConfigFile
[IO.Directory]::SetCurrentDirectory((Convert-Path (Get-Location -PSProvider FileSystem)))
write-host "Your current directory is:" (get-location).Path
Set-AzureVNetConfig -ConfigurationPath $networkConfigFile

#region VM Provisionning
write-host "Virtual machines provisionning..."

$WindowsServer2012ImageName = (GetLatestImage "Windows Server 2012 R2 Datacenter")
$WindowsAndSqlServerImageName = (GetLatestImage "SQL Server 2014 RTM Standard on Windows Server 2012 R2")


# get the credential as PSCredential (same type as what would be retrieved by the following command:
#    $credential = Get-Credential -UserName ".\${adminUsername}"
$SecureStringadminPassword = ConvertTo-SecureString –String $adminPassword –AsPlainText -Force
$credential = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $adminUsername, $SecureStringadminPassword


#create an empty collection of VMConfigs
$vms = @()

Write-Host "creating $dcVMName"

#region create a new VM Config
$newVM = `
    New-AzureVMConfig -ImageName $WindowsServer2012ImageName -InstanceSize $dcInstanceSize -Name $dcVMName `
        -AvailabilitySetName $adAvailabilitySet -DiskLabel "${dcVMName}os" `
        -HostCaching $hostCaching -Label "$dcVMName" |
    Add-AzureProvisioningConfig -Windows -AdminUsername $adminUsername -Password $adminPassword -NoRDPEndpoint |
    Add-AzureDataDisk -CreateNew -DiskSizeInGB 30 -DiskLabel "${DcVmName}data1" -LUN 0 |
    Add-AzureEndpoint -LocalPort 3389 -Name "RDP" -Protocol tcp -PublicPort $dcAdminPort |
    Set-AzureSubnet $dcSubNet
    
#add the VM config to the collection
$vms += ,$newVM

#show the collection
$vms | format-table

#Create the New Cloud Service 
New-AzureService -ServiceName $dcServiceName -Location $location
#create the VM and wait for boot
#New-AzureVM -ServiceName $dcServiceName -VMs $vms -AffinityGroup $affinityGroup -DeploymentLabel $adDeploymentLabel `#             -DeploymentName $adDeploymentName -VNetName $virtualNetworkName -WaitForBoot
New-AzureVM -ServiceName $dcServiceName -VMs $vms -DeploymentLabel $adDeploymentLabel `             -DeploymentName $adDeploymentName -VNetName $virtualNetworkName -WaitForBoot

#endregion

#region install features on DC
$uri = Get-AzureWinRMUri -ServiceName $dcServiceName -Name $dcVmName
InstallWinRMCert $dcServiceName $dcVmName

# Use native PowerShell Cmdlet to execute a script block on the remote virtual machine
Invoke-Command -ConnectionUri $uri.ToString() -Credential $credential `
    -ArgumentList $SecureStringadminPassword, $domainName, $domainNetbiosName -ScriptBlock `
    {
        Param([SecureString]$SecureStringadminPassword,[string]$domainName,[string]$domainNetbiosName)

        $logLabel = $((get-date).ToString("yyyyMMddHHmmss"))
        $logPath = "$env:TEMP\init-webservervm_webserver_install_log_$logLabel.txt"
        Import-Module -Name ServerManager
        Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools -LogPath $logPath


        $disks = Get-Disk | where { $_.NumberOfPartitions -eq 0 } 
        foreach ($d in $disks)
        {
            # there should be one disk only
            $diskNumber = $d.Number
            echo "Format disk $diskNumber"
            Initialize-Disk $diskNumber
            New-Partition -DiskNumber $diskNumber -UseMaximumSize -AssignDriveLetter
            Format-Volume -DriveLetter F -Confirm:$False
            get-volume -DriveLetter F
        }

        echo "Import-module ADDSDeployment"
        Import-module ADDSDeployment
        echo "Install-ADDSForest on $domainName"

		Install-ADDSForest –DomainName $domainName -DomainNetbiosName $domainNetbiosName –DomainMode Win2012 –ForestMode Win2012 `            -InstallDns:$true -DatabasePath "F:\NTDS" -CreateDnsDelegation:$false `
            -LogPath "F:\NTDS" -SysvolPath "F:\SYSVOL" -NoRebootOnCompletion:$false -Force `
            -SafeModeAdministratorPassword $SecureStringadminPassword
  
    } 
#endregion

#region wait for reboot
Start-Sleep -Seconds 45

$dcVm = Get-AzureVM -ServiceName $dcServiceName -Name $dcVmName
While ($dcVm.InstanceStatus -ne "ReadyRole")
{
    write-host "Waiting for DC to be ready... Current Status = " $dcVm.InstanceStatus
    Start-Sleep -Seconds 15
    $dcVm = Get-AzureVM -ServiceName $dcServiceName -Name $dcVmName
}

#endregion

#region SQL Server
$sqlVms = @()

for($i=1; $i -le 2; $i++)
{
    Write-Host "Creating $sqlVMPrefix${i}"
    $adminPort = $sqlAdminPort + $i

    #create a new VM Config
    $newSqlVM = `
        New-AzureVMConfig -ImageName $WindowsAndSqlServerImageName -InstanceSize $sqlInstanceSize -Name "$sqlVMPrefix$i" `
            -AvailabilitySetName $sqlAvailabilitySet -DiskLabel "$sqlVMPrefix${i}os" `
            -HostCaching $hostCaching -Label "$sqlVMPrefix${i}" |
        Add-AzureProvisioningConfig -WindowsDomain -AdminUsername $adminUsername -Password $adminPassword `
        -Domain $domainName -DomainUserName $adminUsername -DomainPassword $adminPassword -JoinDomain $domainName `
        -NoRDPEndpoint |
        Add-AzureDataDisk -CreateNew -DiskSizeInGB 50 -LUN 0 -DiskLabel "$sqlVMPrefix${i}data1" |
        Add-AzureEndpoint -LocalPort 3389 -Name "RDP" -Protocol tcp -PublicPort $adminPort |
        Set-AzureSubnet $sqlBackendSubnet
    
    #add the VM config to the collection
    $sqlVms += ,$newSqlVM
}

#show the collection
$sqlVms | format-table

#Create the New Cloud Service 
New-AzureService -ServiceName $sqlServiceName -Location $location

#create the VM and wait for boot
New-AzureVM -ServiceName $sqlServiceName -VMs $sqlvms -DeploymentLabel $sqlDeploymentLabel `             -DeploymentName $sqlDeploymentName -VNetName $virtualNetworkName -WaitForBoot
#New-AzureVM -ServiceName $sqlServiceName -VMs $sqlvms -AffinityGroup $affinityGroup -DeploymentLabel $sqlDeploymentLabel `#             -DeploymentName $sqlDeploymentName -VNetName $virtualNetworkName -WaitForBoot
#endregion
$d = get-date
Write-Host "Stopping Deployment $d"