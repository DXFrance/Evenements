﻿##########################################
# Connexion à la suscription Azure
##########################################

cls
$Debugpreference  ='SilentlyContinue' 
write-host "-----------------------------------------"
write-host "Getting Images Names from Azure"
write-host "-----------------------------------------"

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
echo $scriptFolder
set-location $scriptFolder
#Import-AzurePublishSettingsFile azure.publishsettings

[IO.Directory]::SetCurrentDirectory((Convert-Path (Get-Location -PSProvider FileSystem)))

#Get-AzureVMImage | ForEach-Object {Write-Host $_.ImageFamily -foregroundcolor cyan}

Get-AzureVMImage | ForEach-Object {Write-Host $_.ImageName -foregroundcolor cyan}

#cls
#$Debugpreference  ='Inquire' 
#$Debugpreference  ='Continue' 
#$vms = Get-AzureVM
#$vms | format-table  -property ImageName

#$vms = Get-AzureVMImage | Where {$_.Label -Match "Visual Studio Ultimate 2013*"} 
#$vms = Get-AzureVMImage
#$vms | format-table  -property ImageName